How to use this chrome extension.

Take the unzipped folder and follow Google instructions for loading the extension. https://developer.chrome.com/extensions/getstarted

The extension only has one working component at the moment. When you click on the hello world icon, a popup should appear. Clicking on the Search For Songs Button will lead to a search bar, where one can search for youtube videos. Clicking on the div that contains the information for each video will open a new youtube window if there is no youtube tab open, or change the current youtube tab to it if there is one open.