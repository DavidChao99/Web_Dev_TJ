
document.getElementById("Search").onclick = function() {
	window.location.href="searchPopup.html";
};
document.getElementById("Playlists").onclick = function() {
	window.location.href="savePopup.html";
};
console.log("HI");